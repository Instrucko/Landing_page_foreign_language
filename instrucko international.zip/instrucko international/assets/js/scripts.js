var $ = jQuery.noConflict();

/* Script on ready
------------------------------------------------------------------------------*/
$(document).ready(function(){
    //do jQuery stuff when DOM is ready

    /* Responsive Jquery Navigation */
    $('.hamburger').click(function(){
        $(this).stop().toggleClass('is-open')
        $('.flyout-megamenu').stop().toggleClass('is-open');
    }); 
    $('.menu-close').click(function(){
        $('.hamburger').stop().removeClass('is-open')
        $('.flyout-megamenu').stop().removeClass('is-open');
    }); 

    $('.flyout-megamenu li:has(ul)').addClass('has-sub'); 
    $('.flyout-megamenu .has-sub>a').after('<span class="submenu-caret"><i class="fa fa-angle-right"></i></span>');

    /* menu open and close on single click */
    $('.flyout-megamenu .has-sub>.submenu-caret').click(function(){
        if($(window).width() <= 768){
            var element = $(this).parent('li');
            if (element.hasClass('is-open')) {
                element.removeClass('is-open');
                element.find('li').removeClass('is-open');
                element.find('ul').slideUp(200);
            }
            else {
                element.addClass('is-open');
                element.children('ul').slideDown(200);
                element.siblings('li').children('ul').slideUp(200);
                element.siblings('li').removeClass('is-open');
                element.siblings('li').find('li').removeClass('is-open');
                element.siblings('li').find('ul').slideUp(200);
            }
        }
    }); 

    /* what we do - slider */
    $('.slick-carousel').slick({
        dots: true,
        infinite: true,
        speed: 500,
        arrows:false,
        fade: true
    });  

    /* projects we’ve worked on!! - syc slider */
    $('.slider-for').slick({
        slidesToShow: 3,
        slidesToScroll: 1,
        arrows: false,
        dots: false,
        fade: true,
        asNavFor: '.slider-nav',
        autoplay: true
    });
    $('.slider-nav').slick({
        slidesToShow:3,
        slidesToScroll: 1,
        asNavFor: '.slider-for',
        dots: true,
        arrows: false,
        focusOnSelect: true,
        vertical: true, 
         responsive: [
    {
      breakpoint: 767,
      settings: {
       vertical: false 
      }
    }
  ]

    });

    /* testimonials carousel */
    $('.testimonials-carousel').slick({
        slidesToShow: 3,
        slidesToScroll: 3,
        arrows: true,
        dots: true,
        fade: true,
    });

    $('.testimonials .slick-prev').click(function() {
        $('.testimonials-carousel').slick('slickPrev');
    });
    $('.testimonials .slick-next').click(function() {
        $('.testimonials-carousel').slick('slickNext');
    });

    /* object animation */
    if($('.wow').length){
        WOW.prototype.addBox = function(element) {
            this.boxes.push(element);
        };

        // Init WOW.js and get instance
        var wow = new WOW();
        wow.init();

        // Attach scrollSpy to .wow elements for detect view exit events,
        // then reset elements and add again for animation
        $('.wow').on('scrollSpy:exit', function() {
            $(this).css({
                'visibility': 'hidden',
                'animation-name': 'none'
            }).removeClass('animated');
            wow.addBox(this);
        }).scrollSpy();
    }

});

/* Script on load
------------------------------------------------------------------------------*/
$(window).load(function() {
    // page is fully loaded, including all frames, objects and images

    $('.floating-btn').addClass('loaded')
});

/* Script on scroll
------------------------------------------------------------------------------*/
$(window).scroll(function() {
    if( $(window).scrollTop() >= $('.main-header').next().offset().top + $('.main-header').height() + 100){
        $('.main-header').addClass('stuck');
    } 
    if( $(window).scrollTop() <= $('.main-header').next().offset().top){
         $('.main-header').removeClass('stuck');
    }
    
});

/* Script on resize
------------------------------------------------------------------------------*/
$(window).resize(function() {

});

/* Script all functions
------------------------------------------------------------------------------*/

